fx_version 'cerulean'
game 'gta5'

author 'BeansFL'
description 'BSC-Notify'
version '1.0'
lua54 'yes'
ui_page {
	'html/index.html',
}

files {
	'html/*.*'
}

client_scripts {
	'cl/main.lua'
}

export 'showNotify'


